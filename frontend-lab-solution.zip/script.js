// Main JS: todo, calendar, gallery, form validation
document.addEventListener('DOMContentLoaded', ()=>{

  // NAV toggle
  const btn = document.getElementById('menuBtn');
  const nav = document.getElementById('nav');
  btn.addEventListener('click', ()=>{
    const open = nav.classList.toggle('open');
    btn.setAttribute('aria-expanded', open);
  });

  // ---------- TODO app ----------
  const todoForm = document.getElementById('todoForm');
  const todoInput = document.getElementById('todoInput');
  const todoList = document.getElementById('todoList');
  const clearCompleted = document.getElementById('clearCompleted');
  const clearAll = document.getElementById('clearAll');
  let todos = JSON.parse(localStorage.getItem('fl_todos') || '[]');

  function saveTodos(){ localStorage.setItem('fl_todos', JSON.stringify(todos)); }
  function renderTodos(){
    todoList.innerHTML = '';
    if(todos.length===0){ todoList.innerHTML = '<li class="muted">No tasks yet</li>'; return; }
    todos.forEach((t,i)=>{
      const li = document.createElement('li');
      const left = document.createElement('div'); left.className='left';
      const chk = document.createElement('input'); chk.type='checkbox'; chk.checked = !!t.done; chk.addEventListener('change', ()=>{ t.done = chk.checked; saveTodos(); renderTodos(); });
      const span = document.createElement('span'); span.textContent = t.text;
      if(t.done) span.style.textDecoration='line-through';
      left.appendChild(chk); left.appendChild(span);
      const actions = document.createElement('div');
      const del = document.createElement('button'); del.className='small-btn'; del.textContent='Delete'; del.addEventListener('click', ()=>{ todos.splice(i,1); saveTodos(); renderTodos(); });
      actions.appendChild(del);
      li.appendChild(left); li.appendChild(actions);
      todoList.appendChild(li);
    });
  }

  todoForm.addEventListener('submit', e=>{
    e.preventDefault();
    const val = todoInput.value.trim();
    if(!val) return alert('Enter a task');
    todos.push({text:val, done:false, created:Date.now()});
    todoInput.value=''; saveTodos(); renderTodos();
  });
  clearCompleted.addEventListener('click', ()=>{ todos = todos.filter(t=>!t.done); saveTodos(); renderTodos(); });
  clearAll.addEventListener('click', ()=>{ if(confirm('Clear all tasks?')){ todos=[]; saveTodos(); renderTodos(); } });
  renderTodos();

  // ---------- Calendar (simple) ----------
  const monthLabel = document.getElementById('monthLabel');
  const calendarGrid = document.getElementById('calendarGrid');
  let viewDate = new Date();
  function renderCalendar(date){
    calendarGrid.innerHTML='';
    const year = date.getFullYear(), month = date.getMonth();
    monthLabel.textContent = date.toLocaleString(undefined, {month:'long', year:'numeric'});
    const first = new Date(year, month, 1);
    const last = new Date(year, month+1, 0);
    const startDay = first.getDay(); // 0 sun..6 sat
    // weekday headings
    const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    days.forEach(d=>{
      const hd = document.createElement('div'); hd.className='calendar-cell'; hd.innerHTML = '<strong>'+d+'</strong>'; hd.style.background='#f3f4f6'; calendarGrid.appendChild(hd);
    });
    // empty cells for start
    for(let i=0;i<startDay;i++){ const c=document.createElement('div'); c.className='calendar-cell'; calendarGrid.appendChild(c); }
    // days
    for(let d=1; d<=last.getDate(); d++){
      const c = document.createElement('div'); c.className='calendar-cell';
      const dateEl = document.createElement('div'); dateEl.className='date'; dateEl.textContent = d;
      c.appendChild(dateEl);
      // sample: highlight today
      const today = new Date();
      if(d===today.getDate() && month===today.getMonth() && year===today.getFullYear()){ c.style.border='2px solid var(--accent)'; }
      calendarGrid.appendChild(c);
    }
  }
  document.getElementById('prevMonth').addEventListener('click', ()=>{ viewDate = new Date(viewDate.getFullYear(), viewDate.getMonth()-1, 1); renderCalendar(viewDate); });
  document.getElementById('nextMonth').addEventListener('click', ()=>{ viewDate = new Date(viewDate.getFullYear(), viewDate.getMonth()+1, 1); renderCalendar(viewDate); });
  renderCalendar(viewDate);

  // ---------- Gallery (sample static data) ----------
  const sampleImages = [
    {title:'Sunset', src:'https://images.unsplash.com/photo-1501973801540-537f08ccae7b?auto=format&fit=crop&w=800&q=60'},
    {title:'Mountains', src:'https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=800&q=60'},
    {title:'Forest', src:'https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=800&q=60'},
    {title:'City', src:'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?auto=format&fit=crop&w=800&q=60'}
  ];
  const galleryGrid = document.getElementById('galleryGrid');
  function renderGallery(){
    galleryGrid.innerHTML = sampleImages.map(img=>`
      <div class="card">
        <img src="${img.src}" alt="${img.title}" loading="lazy"/>
        <div><strong>${img.title}</strong></div>
      </div>
    `).join('');
  }
  renderGallery();

  // ---------- Contact form validation ----------
  const contactForm = document.getElementById('contactForm');
  const contactMsg = document.getElementById('contactMsg');
  contactForm.addEventListener('submit', e=>{
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();
    if(name.length < 2){ contactMsg.textContent='Name must be at least 2 characters.'; return; }
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){ contactMsg.textContent='Enter a valid email.'; return; }
    if(message.length < 10){ contactMsg.textContent='Message must be at least 10 characters.'; return; }
    // simulate send
    contactMsg.textContent = 'Message sent (simulated). Thank you!';
    contactForm.reset();
    setTimeout(()=> contactMsg.textContent = '', 4000);
  });

});