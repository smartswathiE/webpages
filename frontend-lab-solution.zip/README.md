# Frontend Labs Assignment - Solution

This repository contains a complete frontend project solving common frontend lab tasks:
- Responsive layout and navigation
- Tasks (To‑Do list) with localStorage persistence
- Simple calendar view (monthly)
- Image gallery (sample data)
- Contact form with validation

## How to run locally

1. Download and unzip the project.
2. Open `index.html` in your browser or run a simple local server (recommended):
   - Using Python 3: `python -m http.server 8000`
   - Then open http://localhost:8000 in your browser.

## How to push to GitHub (commands)

```bash
git init
git add .
git commit -m "Initial: Frontend Labs Assignment solution"
# create a repo on GitHub, then:
git remote add origin https://github.com/USERNAME/REPO.git
git branch -M main
git push -u origin main
```

If you want, I can generate a ready zip and provide instructions. I cannot push to your GitHub for you, but I will guide each step.
